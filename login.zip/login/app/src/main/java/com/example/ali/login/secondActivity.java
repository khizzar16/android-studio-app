package com.example.ali.login;

import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class secondActivity extends AppCompatActivity {
    ImageView levise;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        levise= findViewById(R.id.imageView1);

    }
    public void onButtonclick(View v)
    {
        Intent i;
        i = new Intent(secondActivity.this,thirdactivity.class);
        startActivity(i);
    }

    public void onButtonclick1(View v)
    {
        Intent i;
        i = new Intent(secondActivity.this,fourthactivity.class);
        startActivity(i);
    }
}
